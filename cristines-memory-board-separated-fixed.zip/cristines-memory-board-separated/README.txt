Cristine's Memory Board - separated project files

Folder structure:
- index.html: page structure
- css/style.css: all styles
- js/script.js: all JavaScript and memory data
- assets/: extracted images used by the memory board

To run: keep the folders together and open index.html in a browser.
Internet access is needed for the Google Fonts used by the page.
