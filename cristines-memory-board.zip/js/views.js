const visited = new Set();
let SECRET_ON = false, current = null, curGroup = null, busy = false;
let lbList = [], lbI = 0, flipped = new Set(), pts = 0;

const visibleIdx = () => folders.map((f, i) => i).filter(i => !folders[i].hidden || SECRET_ON);
const hintOf = f => f.t === "gallery" ? (f.photos.length ? `${f.photos.length} photos` : "add your photos") : HINT[f.t];
const toast = msg => { const t = $("#toast"); t.textContent = msg; t.classList.add("on"); clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove("on"), 2600); };
const reveal = root => root.querySelectorAll(".rv").forEach((el, k) => {
  el.style.setProperty("--d", Math.min(k, 12) * 70 + "ms");
  requestAnimationFrame(() => el.classList.add("in"));
});

/* ---------- home ---------- */
function renderHome(){
  const gi = groups.map((g, i) => i).filter(i => !groups[i].hidden || SECRET_ON);
  $("#board").innerHTML = gi.map((i, row) => {
    const g = groups[i], n = g.kids.filter(k => visited.has(k)).length;
    const hn = g.kids.length > 1 ? `${g.kids.length} folders${n ? ` · ${n} opened` : ""}` : hintOf(folders[g.kids[0]]);
    return folderBtn({data:`data-g="${i}"`, row, name:g.name, hint:hn});
  }).join("");
  $("#count").textContent = `${visited.size} of ${REQUIRED} folders opened`;
  $("#pips").innerHTML = Array.from({length:REQUIRED}, (_, k) => `<i class="${k < visited.size ? "on" : ""}">♥</i>`).join("");
}

/* ---------- inside views ---------- */
const PH_ICON = `<svg viewBox="0 0 120 90" aria-hidden="true"><use href="#kuromi"/></svg>`;
const slot = (label, n) => `<figure class="ph empty"><div class="im">${PH_ICON}<span>${esc(label)} ${n}</span></div></figure>`;
const figHtml = (p, i) => `<figure class="ph" data-s="${i}" tabindex="0" role="button" aria-label="Enlarge photo: ${esc(p.name)}" style="--n:${i}">
  <div class="im"><img loading="lazy" src="${esc(p.src)}" alt="${esc(p.name)}"></div>
  <figcaption><b>${esc(p.name)}</b>${p.text ? `<span>${esc(p.text)}</span>` : ""}</figcaption></figure>`;
const gridHtml = (photos, layout, n, label) =>
  `<div class="l-${layout}">${photos.length ? photos.map(figHtml).join("") : Array.from({length:n}, (_, k) => slot(label, k + 1)).join("")}</div>`;
const videoBox = (src, label) => `<div class="mv rv">${src ? `<video controls playsinline preload="metadata" src="${esc(src)}"></video>` : `<span>Add your ${label} video in MEDIA</span>`}</div>`;

function foodHtml(){
  return `<div class="food">
    <div class="rv"><div class="dish-img">${MEDIA.food ? `<img src="${esc(MEDIA.food)}" alt="${esc(FOOD.title)}">` : `<span>Add your dish photo<br>in MEDIA</span>`}</div></div>
    <div>
      <h2 class="dish rv">${esc(FOOD.title)}</h2>
      <p class="tagline rv">${esc(FOOD.tag)}</p>
      <span class="meta rv">${esc(FOOD.meta)}</span>
      <div class="recipe rv">
        <div class="tabs" role="tablist">
          <button class="on" data-tab="ing" role="tab" aria-selected="true" type="button">Ingredients</button>
          <button data-tab="steps" role="tab" aria-selected="false" type="button">Steps</button>
        </div>
        <div class="pane" data-p="ing"><ul class="ing">${FOOD.ing.map(t => `<li><label><input type="checkbox"><span>${esc(t)}</span></label></li>`).join("")}</ul>
          <p class="tip">${esc(FOOD.tip)}</p>
          <p class="prog" id="fprog">0 of ${FOOD.ing.length} ready</p></div>
        <div class="pane" data-p="steps" hidden><ol class="steps">${FOOD.steps.map(s => `<li>${esc(s)}</li>`).join("")}</ol></div>
      </div>
    </div></div>`;
}
function movieHtml(){
  return `<div class="stack">${videoBox(MEDIA.movie, "movie")}
    <div class="syn rv"><h3>Story</h3>${SYNOPSIS.split("\n\n").map(p => `<p>${esc(p)}</p>`).join("")}</div>
    <div class="rv"><h3>The cast</h3>
      <div class="cast">${CAST.map((c, i) => `<button class="cm" type="button" data-ci="${i}"><span class="av">${MEDIA.cast[i] ? `<img loading="lazy" src="${esc(MEDIA.cast[i])}" alt="${esc(c.name)}">` : esc(c.role[0])}</span><b>${esc(c.role)}</b><span>${esc(c.name)}</span></button>`).join("")}</div>
      <div class="bio" id="bio" aria-live="polite"></div></div>
    <div class="rv"><h3>Photos</h3>${gridHtml(MEDIA.movieStills, "cine", 4, "Movie still")}</div>
  </div>`;
}
function songHtml(){
  return `<div class="stack"><p class="songname rv">♪ Alive · Planetshakers</p>${videoBox(MEDIA.song, "song")}
    <div class="rv"><div class="lyr" id="lyr"><p class="now">Add the lyrics below to follow along as the song plays.</p></div>
      <details class="lyr-edit"${LYRICS ? "" : " open"}><summary>Add or change lyrics</summary>
        <textarea id="lyr-text" rows="8" spellcheck="false" placeholder="Paste the lyrics here, one line per row.">${esc(LYRICS)}</textarea>
        <button class="btn" id="lyr-save" type="button">Use these lyrics</button></details></div>
    <div class="why rv"><h3>Why I love this song</h3><p>${esc(WHY)}</p></div>
    <div class="rv"><h3>Photos</h3>${gridHtml(MEDIA.songPhotos, "circles", 5, "Song photo")}</div>
  </div>`;
}
const REWARDS = [{i:"🎀",n:"Pink Bow"},{i:"💜",n:"Violet Heart"},{i:"💀",n:"Mini Skull"},{i:"⭐",n:"Lucky Star"},{i:"🍭",n:"Sweet Candy"},{i:"👑",n:"Kuromi Crown"}];
const trayHtml = () => JOKES.map((_, k) => `<span class="slot${flipped.has(k) ? " got" : ""}" title="${flipped.has(k) ? esc(REWARDS[k].n) : "Flip card " + (k + 1) + " to unlock"}">${flipped.has(k) ? REWARDS[k].i : "?"}</span>`).join("");
function jokesHtml(){
  return `<div class="rwd rv"><div class="pts">♥ <b id="pts">${pts}</b> points</div><div class="tray" id="tray">${trayHtml()}</div></div>
    <div class="cards">${JOKES.map((j, i) => `<div class="fc rv${flipped.has(i) ? " flip" : ""}" role="button" tabindex="0" data-j="${i}" aria-pressed="${flipped.has(i)}" aria-label="Joke ${i + 1}"><div class="in">
      <div class="side f"><span class="n">${pad2(i + 1)}</span><p>${esc(j[0])}</p><small><span>Tap to flip</span><span>${i + 1}/${JOKES.length}</span></small></div>
      <div class="side b"><span class="stk">${REWARDS[i].i}</span><small>Punchline</small><p>${esc(j[1])}</p><small><span>+10 ♥</span><span>${i + 1}/${JOKES.length}</span></small></div>
    </div></div>`).join("")}</div>
    <p class="jcount" id="jcount">Punchlines found ${flipped.size} of ${JOKES.length}</p>`;
}
function reward(fc){
  const j = +fc.dataset.j, first = !flipped.has(j), r = REWARDS[j];
  flipped.add(j); pts += 10;
  const b = $("#pts"); b.textContent = pts; retrigger(b, "bump");
  $("#jcount").textContent = `Punchlines found ${flipped.size} of ${JOKES.length}`;
  const rc = fc.getBoundingClientRect(); spark(rc.left + rc.width / 2, rc.top + rc.height / 2, first ? 16 : 8, true);
  if (first){ $("#tray").innerHTML = trayHtml(); $("#tray").children[j].classList.add("pop"); }
  if (first && flipped.size === JOKES.length){
    toast("You collected every sticker. Joke champion! 👑");
    [0, 300, 600].forEach(t => setTimeout(() => spark(innerWidth * (.25 + Math.random() * .5), innerHeight * (.25 + Math.random() * .3), 18, true), t));
  } else toast(first ? `+10 ♥ · You got the ${r.n} ${r.i}` : "+10 ♥");
}
function secretHtml(){
  return `<div class="credits"><div class="roll">${CREDITS.map(([a, b]) => `<p>${a ? `<small>${esc(a)}</small>` : ""}${b ? `<b>${esc(b)}</b>` : ""}</p>`).join("")}</div></div>
    <button class="replay" id="replay" type="button">Roll the credits again</button>`;
}

const VIEW = {
  gallery: f => ({note: f.photos.length ? "Click any photo to enlarge it." : "These are placeholders. Add your photos in MEDIA and they will appear here.", html: gridHtml(f.photos, f.layout, f.ph, f.label)}),
  food:    () => ({note:"Tick off the ingredients as you cook, then follow the steps.", html: foodHtml()}),
  movie:   () => ({note:"Press play, pick a character to meet the cast, and click any photo to enlarge it.", html: movieHtml()}),
  song:    () => ({note:"Press play and the lyrics will follow along with the music.", html: songHtml()}),
  jokes:   () => ({note:"Tap a card to see the punchline. Every flip earns points, and each new card wins a sticker.", html: jokesHtml()}),
  secret:  () => ({note:"You found the hidden folder. Roll the credits.", html: secretHtml()})
};

function buildInside(i){
  const f = folders[i], v = VIEW[f.t](f);
  const g = groups[groupOf(i)];
  $("#kicker").textContent = g.kids.length > 1 ? `${g.name} · ${g.kids.indexOf(i) + 1} of ${g.kids.length}` : "Folder";
  $("#ititle").textContent = f.name;
  $("#inote").textContent = v.note;
  $("#body").classList.remove("bare");
  $("#body").innerHTML = v.html;
  wireInside(f);
}

function wireInside(f){
  const B = $("#body");
  if (f.t === "food") {
    const boxes = [...B.querySelectorAll(".ing input")];
    boxes.forEach(b => b.addEventListener("change", () => {
      const n = boxes.filter(x => x.checked).length;
      $("#fprog").textContent = `${n} of ${boxes.length} ready`;
      if (n === boxes.length) toast("Everything is ready. Enjoy!");
    }));
  }
  if (f.t === "song") {
    const v = B.querySelector("video");
    let L = LYRICS.split("\n").map(s => s.trim()).filter(Boolean);
    const draw = idx => {
      const now = $("#lyr .now");
      now.textContent = L.length ? L[Math.max(0, Math.min(idx, L.length - 1))] : "Add the lyrics below to follow along as the song plays.";
    };
    draw(0);
    B.querySelector("#lyr-save").addEventListener("click", () => {
      L = $("#lyr-text").value.split("\n").map(s => s.trim()).filter(Boolean);
      toast(L.length ? "Lyrics saved for this visit" : "Add a few lines first"); draw(0);
    });
    v?.addEventListener("timeupdate", () => { if (L.length && v.duration) draw(Math.floor(v.currentTime / v.duration * L.length)); });
  }
  if (f.t === "movie") { B.querySelector(".cm")?.classList.add("sel"); showBio(0, true); }
  if (f.t === "secret") B.querySelector("#replay").addEventListener("click", () => {
    restartAnim(B.querySelector(".roll"));
  });
  reveal(B.parentElement);
}

function showBio(i, quiet){
  const c = CAST[i], el = $("#bio"); if (!c || !el) return;
  document.querySelectorAll(".cm").forEach(x => { const on = +x.dataset.ci === i; x.classList.toggle("sel", on); x.setAttribute("aria-pressed", on); });
  el.style.opacity = 0;
  setTimeout(() => { el.innerHTML = `<b>${esc(c.role)}</b> · ${esc(c.name)}<br><span>${esc(c.bio)}</span>`; el.style.opacity = 1; }, quiet ? 0 : 180);
}
