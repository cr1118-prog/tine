/* ---------- lightbox ---------- */
function drawLB(){
  const p = lbList[lbI], im = $("#lb-img");
  im.style.opacity = 0;
  setTimeout(() => { im.src = p.src; im.alt = p.name; im.style.opacity = 1; }, 160);
  $("#lb-cap").innerHTML = `<b>${esc(p.name)}</b>${p.text ? esc(p.text) : ""}`;
  $("#lb-n").textContent = `${lbI + 1} / ${lbList.length}`;
  $("#lb-prev").hidden = $("#lb-next").hidden = lbList.length < 2;
}
let lbOpener = null;
function openLB(list, i){
  lbOpener = document.activeElement; lbList = list; lbI = i; drawLB();
  $("#lb").classList.add("on"); document.body.classList.add("lock"); $("#lb-x").focus();
}
function closeLB(){ $("#lb").classList.remove("on"); document.body.classList.remove("lock"); lbOpener?.focus?.(); }
function stepLB(d){ lbI = (lbI + d + lbList.length) % lbList.length; drawLB(); }

/* photos that belong to the folder being viewed (movie/song use their own lists) */
const photosOf = f => f.t === "movie" ? MEDIA.movieStills : f.t === "song" ? MEDIA.songPhotos : f.photos;
