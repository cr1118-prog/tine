const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const pad2 = n => String(n).padStart(2, "0");
const CALM = matchMedia("(prefers-reduced-motion: reduce)").matches;
/* re-run a CSS class animation / inline animation from the start */
const retrigger = (el, cls) => { el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); };
const restartAnim = el => { el.style.animation = "none"; void el.offsetWidth; el.style.animation = ""; };
const KUROMI = `<svg class="kh" viewBox="0 0 120 90" aria-hidden="true"><use href="#kuromi"/></svg>`;

/* one folder card, used on the board and inside collections */
const folderBtn = ({data, row, name, hint}) =>
  `<div class="fdw" style="--k:${row}"><button class="fd" type="button" ${data}>${KUROMI}<span class="no">${pad2(row + 1)}</span><span class="nm">${esc(name)}</span><span class="hn">${esc(hint)}</span></button></div>`;
