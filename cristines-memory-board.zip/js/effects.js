/* ---------- extras: floating depth layer, sparkles, hero life ---------- */
const GL = ["♥","✦","✧","☆","♡","✿"], fx = $("#fx");
for (let k = 0; k < 26; k++){
  const s = document.createElement("span"), z = Math.random() * .9 + .1;
  s.className = "fl"; s.textContent = GL[k % GL.length];
  s.style.cssText = `left:${Math.random()*100}%;top:${Math.random()*100}%;font-size:${10+z*26}px;opacity:${.18+z*.4};filter:blur(${(1-z)*2.5}px);--z:${z};animation-duration:${6+Math.random()*8}s;animation-delay:-${Math.random()*8}s;color:${k%4?"#8a63dc":"#ff8fc8"}`;
  fx.appendChild(s);
}
for (let k = 0; k < 5; k++){
  const z = Math.random() * .7 + .3, e = document.createElement("div");
  e.className = "fl"; e.style.cssText = `left:${8+k*20+Math.random()*8}%;top:${10+Math.random()*75}%;opacity:${.12+z*.2};filter:blur(${(1-z)*3}px);--z:${z};animation-duration:${9+Math.random()*6}s;animation-delay:-${Math.random()*8}s`;
  e.innerHTML = `<svg viewBox="0 0 120 90" width="${40+z*50}" height="${30+z*38}"><use href="#kuromi"/></svg>`;
  fx.appendChild(e);
}
const spark = (x, y, n = 1, burst) => {
  if (CALM) return;
  for (let k = 0; k < n; k++){
    const s = document.createElement("i"), a = Math.random() * 6.28, d = burst ? 40 + Math.random() * 60 : 14 + Math.random() * 10;
    s.className = "sp"; s.textContent = GL[Math.random() * GL.length | 0];
    s.style.cssText = `left:${x}px;top:${y}px;--dx:${Math.cos(a)*d}px;--dy:${Math.sin(a)*d-(burst?20:0)}px;color:${Math.random()<.5?"#ff8fc8":"#7b4fd6"};font-size:${burst?14+Math.random()*10:10}px`;
    document.body.appendChild(s); setTimeout(() => s.remove(), 900);
  }
};
let lastT = 0;
addEventListener("pointermove", e => {
  if (e.pointerType === "mouse") fx.style.setProperty("--mx", (e.clientX / innerWidth - .5) * 2);
  if (e.pointerType === "mouse") fx.style.setProperty("--my", (e.clientY / innerHeight - .5) * 2);
  if (e.pointerType === "mouse" && e.timeStamp - lastT > 90){ lastT = e.timeStamp; spark(e.clientX, e.clientY, 1); }
});
addEventListener("pointerdown", e => spark(e.clientX, e.clientY, 8, 1));
(function wave(n, i = {v:0}){ [...n.childNodes].forEach(c => {
  if (c.nodeType === 3){ const f = document.createDocumentFragment();
    [...c.textContent].forEach(ch => { const s = document.createElement("span"); s.className = "ch"; s.style.setProperty("--i", i.v++); s.textContent = ch; f.appendChild(s); });
    c.replaceWith(f);
  } else wave(c, i);
}); })($(".title"));
$(".tape-in").innerHTML = "<b>♥ memories ✦ photos ♥ stories ✦ moments ✦ </b>".repeat(8);
const MSG = ["hi Cristine ♡","pick a folder!","so many memories ✦","you’re doing great ♥","psst… find the secret"];
let mi = 0;
setInterval(() => { const b = $("#bub"); if (!b) return; restartAnim(b); b.textContent = MSG[++mi % MSG.length]; }, 3600);
$(".hk svg").addEventListener("click", () => { const h = $(".hk"); retrigger(h, "jump"); });
