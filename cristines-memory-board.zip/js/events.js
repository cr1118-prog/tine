/* ---------- events ---------- */
$("#board").addEventListener("click", e => {
  const b = e.target.closest(".fd"); if (!b) return;
  const gi = +b.dataset.g, g = groups[gi];
  if (g.kids.length === 1){ curGroup = null; openFolder(g.kids[0], b); } else openGroup(gi, b);
});
$("#back").addEventListener("click", closeFolder);
$("#body").addEventListener("click", e => {
  const fd = e.target.closest(".fd"); if (fd){ openFolder(+fd.dataset.i, fd); return; }
  const ph = e.target.closest(".ph:not(.empty)"); if (ph){ openLB(photosOf(folders[current]), +ph.dataset.s); return; }
  const cm = e.target.closest(".cm"); if (cm){ showBio(+cm.dataset.ci); return; }
  const tab = e.target.closest(".tabs button");
  if (tab){
    document.querySelectorAll(".tabs button").forEach(x => { x.classList.toggle("on", x === tab); x.setAttribute("aria-selected", x === tab); });
    document.querySelectorAll(".pane").forEach(p => p.hidden = p.dataset.p !== tab.dataset.tab);
    return;
  }
  const fc = e.target.closest(".fc");
  if (fc){
    fc.classList.toggle("flip"); fc.setAttribute("aria-pressed", fc.classList.contains("flip"));
    if (fc.classList.contains("flip")) reward(fc);
  }
});
$("#body").addEventListener("keydown", e => {
  if (e.key !== "Enter" && e.key !== " ") return;
  const t = e.target.closest?.(".fc, .ph:not(.empty)");
  if (t){ e.preventDefault(); t.click(); }
});
$("#lb-x").addEventListener("click", closeLB);
$("#lb-prev").addEventListener("click", () => stepLB(-1));
$("#lb-next").addEventListener("click", () => stepLB(1));
$("#lb").addEventListener("click", e => { if (e.target.id === "lb") closeLB(); });
document.addEventListener("keydown", e => {
  if ($("#lb").classList.contains("on")){
    if (e.key === "Escape") closeLB();
    if (e.key === "ArrowLeft") stepLB(-1);
    if (e.key === "ArrowRight") stepLB(1);
    return;
  }
  if (e.key === "Escape" && (current !== null || curGroup !== null)) closeFolder();
});

/* ---------- loader ---------- */
let loaderGone = false;
function hideLoader(){
  if (loaderGone) return; loaderGone = true;
  $("#loader").classList.add("done");
  setTimeout(() => { $("#loader").hidden = true; reveal($("#home")); $("#board").classList.add("in"); }, 350);
}
$("#loader").addEventListener("click", hideLoader);
$("#loader").addEventListener("keydown", e => { if (["Enter", " ", "Escape"].includes(e.key)) { e.preventDefault(); hideLoader(); } });
setTimeout(hideLoader, CALM ? 700 : 2800);
