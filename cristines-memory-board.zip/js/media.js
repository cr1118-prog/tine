/* =====================================================================
   ADD YOUR OWN MEDIA HERE
   Photos: {src:"assets/images/me.jpg", name:"Title", text:"Optional story"}
   Leave an array empty to show cute placeholder frames instead.
   ===================================================================== */
const MEDIA = {
  childhood: [
  {
    "src": "assets/images/childhood-1.jpg",
    "name": "Happy 1st Birthday",
    "text": "Balloons, a pink walker and a curious little face."
  },
  {
    "src": "assets/images/childhood-2.jpg",
    "name": "Sitting pretty",
    "text": "A pink dress, little sandals and a plastic chair."
  },
  {
    "src": "assets/images/childhood-3.jpg",
    "name": "Morning walk",
    "text": "A walk together down the road, 22 Oct 2017."
  },
  {
    "src": "assets/images/childhood-4.jpg",
    "name": "Scout day",
    "text": "Yellow neckerchiefs, matching caps and big smiles."
  },
  {
    "src": "assets/images/childhood-5.jpg",
    "name": "Together by the wall",
    "text": "Posing in front of the house with the dog."
  }
],   // polaroid scatter
  family: [
  {
    "src": "assets/images/family-1.jpg",
    "name": "Garden group photo",
    "text": "Everyone together among the palm trees."
  },
  {
    "src": "assets/images/family-2.jpg",
    "name": "Peace sign pair",
    "text": "Two peace signs and a cozy lean-in."
  },
  {
    "src": "assets/images/family-3.jpg",
    "name": "New Year gathering",
    "text": "Ringing in 2025 together with a table full of food."
  },
  {
    "src": "assets/images/family-4.jpg",
    "name": "Night of lights",
    "text": "Everyone squeezing into the glowing light arch."
  },
  {
    "src": "assets/images/family-5.jpg",
    "name": "Carnival night",
    "text": "Big smiles in front of the carousel."
  }
],   // filmstrip
  friends:    [{"src":"assets/images/friends-1.jpg","name":"My friends","text":"The people who make my days brighter."},{"src":"assets/images/friends-2.jpg","name":"Silly moments","text":"Peace signs and funny faces."},{"src":"assets/images/friends-3.jpg","name":"The whole gang","text":"All of us together under the trees."},{"src":"assets/images/friends-4.jpg","name":"Lunch together","text":"Good food and good company."},{"src":"assets/images/friends-5.jpg","name":"Out and about","text":"A quick selfie on our day out."}],  // masonry collage
  love:      [{"src":"assets/images/love-1.jpg","name":"Together","text":"Side by side, silly faces and all."},{"src":"assets/images/love-2.jpg","name":"Always close","text":"Hanging out at home."},{"src":"assets/images/love-3.jpg","name":"Sunset walk","text":"Standing tall under the evening sky."},{"src":"assets/images/love-4.jpg","name":"Little builder","text":"Ready for work with a yellow hard hat."}],   // duet hero grid
  movieStills: [{"src":"assets/images/movie-stills-1.jpg","name":"Into the snow","text":"A favorite scene from my favorite movie."},{"src":"assets/images/movie-stills-2.jpg","name":"Frozen kingdom","text":"A cold, magical moment I love."},{"src":"assets/images/movie-stills-3.jpg","name":"The Lion, the Witch and the Wardrobe","text":"The story that started it all."},{"src":"assets/images/movie-stills-4.jpg","name":"A winter meeting","text":"Snowy woods and a surprise friend."}], // cinema frames
  songPhotos:  [{"src":"assets/images/song-photos-1.jpg","name":"Legacy: Alive Again","text":"The album cover for my favorite song."},{"src":"assets/images/song-photos-2.jpg","name":"Alive Again","text":"Planetshakers, live."}], // bubbles
  food: "assets/images/food.jpg",        // one photo of your dish
  movie: "assets/videos/movie.mp4",       // video file, e.g. "videos/movie.mp4"
  song: "assets/videos/song.mp4",        // video file, e.g. "videos/song.mp4"
  cast: []         // optional cast photos, same order as CAST
};
