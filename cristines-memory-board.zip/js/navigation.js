/* ---------- navigation ---------- */
function buildGroup(gi){
  const g = groups[gi];
  $("#kicker").textContent = "Collection";
  $("#ititle").textContent = g.name;
  $("#inote").textContent = g.note;
  const b = $("#body"); b.classList.add("bare");
  b.innerHTML = `<div class="board sub in ${g.kids.length === 3 ? "c3" : "c2"}">${g.kids.map((i, row) => {
    const f = folders[i];
    return folderBtn({data:`data-i="${i}"`, row, name:f.name, hint:hintOf(f) + (visited.has(i) ? " ✓" : "")});
  }).join("")}</div>`;
  reveal($("#inside"));
}
function showInside(){
  const g = curGroup !== null ? groups[curGroup] : null;
  $("#back").textContent = current !== null && g && g.kids.length > 1 ? `← Back to ${g.name}` : "← Back to the board";
  $("#home").hidden = true; $("#inside").hidden = false;
  $("#inside").classList.remove("in");
  $("#topbar").classList.add("on");
  window.scrollTo(0, 0);
  requestAnimationFrame(() => requestAnimationFrame(() => { $("#inside").classList.add("in"); busy = false; }));
}
function pressFx(src){
  if (!src) return;
  src.closest(".board")?.classList.add("opening"); src.classList.add("opening");
  const r = src.getBoundingClientRect(); spark(r.left + r.width / 2, r.top + r.height / 2, 14, 1);
}
function openFolder(i, src){
  if (busy) return; busy = true; current = i; pressFx(src);
  setTimeout(() => {
    buildInside(i); showInside();
    if (!folders[i].hidden){
      visited.add(i);
      if (visited.size >= REQUIRED && !SECRET_ON){ SECRET_ON = true; setTimeout(() => toast("A hidden folder appeared on the board"), 700); }
    }
  }, CALM ? 0 : 440);
}
function openGroup(gi, src){
  if (busy) return; busy = true; curGroup = gi; current = null; pressFx(src);
  setTimeout(() => { buildGroup(gi); showInside(); }, CALM ? 0 : 440);
}
function closeFolder(){
  if (busy || (current === null && curGroup === null)) return; busy = true;
  const toGroup = current !== null && curGroup !== null && groups[curGroup].kids.length > 1;
  $("#inside").classList.remove("in");
  if (!toGroup) $("#topbar").classList.remove("on");
  setTimeout(() => {
    current = null;
    if (toGroup){ buildGroup(curGroup); showInside(); return; }
    curGroup = null;
    $("#inside").hidden = true; $("#home").hidden = false;
    $("#board").classList.remove("in", "opening");
    renderHome(); window.scrollTo(0, 0);
    requestAnimationFrame(() => requestAnimationFrame(() => { $("#board").classList.add("in"); busy = false; }));
  }, CALM ? 0 : 420);
}
